﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LoseMenu : MonoBehaviour
{
    public bool Lose = false;
    public GameObject loseMenuUI;
    // Start is called before the first frame update


    // Update is called once per frame
    public void Update()
    {
        if (Lose == true)
        {
            Pause();
           
        }
        else
        {
            Resume();
        }
    }
    public void Resume()
    {
        loseMenuUI.SetActive(false);
        Time.timeScale = 1f;
        Lose = false;
    }
    public void Pause()
    {
        Time.timeScale = 0f;
        Debug.Log("You died");
        loseMenuUI.SetActive(true);
        Lose = true;
    }
    public void Restart()
    {
        Scene scene = SceneManager.GetActiveScene();
        SceneManager.LoadScene(scene.name);
    }
    public void Quit()
    {
        SceneManager.LoadScene("Menu");
    }
}


