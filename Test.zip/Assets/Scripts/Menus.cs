﻿//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;
//using UnityEngine.SceneManagement;

//public class Menus : MonoBehaviour
//{
//    // Start is called before the first frame update
//    public bool Win = false;
//    public GameObject winMenuUI;
//    public bool Lose = false;
//    public GameObject loseMenuUI;
//    public bool GameIsPaused = false;
//    public GameObject PauseMenuUI;

//    // Update is called once per frame

//    public void Update()
//    {

//        if (Win == true)
//        {
//            Pause();
//            winMenuUI.SetActive(true);
//            Debug.Log("Paused");
//        }
//        else
//        {
//            Resume();
//            winMenuUI.SetActive(false);
//        }

//        if (Lose == true)
//        {
//            Pause();
//            loseMenuUI.SetActive(true);
//        }
//        else
//        {
//            Resume();
//            loseMenuUI.SetActive(false);
//        }

//        if (Input.GetKeyDown(KeyCode.Escape))
//        {
//            if (GameIsPaused == true)
//            {
//                Resume();
//                PauseMenuUI.SetActive(false);
//            }
//            else
//            {
//                Pause();
//                PauseMenuUI.SetActive(true);
//            }
//        }
//    }
//    public void Resume()
//    {
        
//        Time.timeScale = 1f;
//        Win = false;
//    }
//    public void Pause()
//    {
        
//        Time.timeScale = 0f;
//        Win = true;
//    }
//    public void Restart()
//    {
//        Scene scene = SceneManager.GetActiveScene();
//        SceneManager.LoadScene(scene.name);
//    }
//    public void Quit()
//    {
//        SceneManager.LoadScene("Menu");
//    }
//    public void NextLevel()
//    {
//        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
//    }
//}
