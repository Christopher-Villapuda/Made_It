﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelEnd : MonoBehaviour
{

    //private bool goalReached = true;
    private Timer timer;
    public GameObject goal;
    public GameObject WM;
    private PlayerController player;
    private WinMenu wm;
    // Start is called before the first frame update
    void Start()
    {
        timer = goal.GetComponent<Timer>();
        player = GetComponent<PlayerController>();
        wm = WM.GetComponent<WinMenu>();

    }

    // Update is called once per frame
    void Update()
    {    
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        //Timer timer = new Timer();
        if (collision.gameObject.tag.Equals("Player"))
        {
            Destroy(GetComponent<BoxCollider2D>());
            timer.timerActive = false;
            //player.GetComponent<PlayerController>().enabled = false;
            wm.Win = true; 
        }

    }

}
