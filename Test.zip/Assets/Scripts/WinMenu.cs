﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class WinMenu : MonoBehaviour
{
    public  bool Win = false;
    public GameObject winMenuUI;


    // Update is called once per frame

    public void Update()
    {

        if (Win == true)
        {
            Pause();
            Debug.Log("Paused");
        }
        else
        {
            Resume();
        }
    }
    public void Resume()
    {
        winMenuUI.SetActive(false);
        Time.timeScale = 1f;
        Win = false;
    }
    public void Pause()
    {
        winMenuUI.SetActive(true);
        Time.timeScale = 0f;
        Win = true;
    }
    public void Restart()
    {
        Scene scene = SceneManager.GetActiveScene();
        SceneManager.LoadScene(scene.name);
    }
    public void Quit()
    {
        SceneManager.LoadScene("Menu");
    }
    public void NextLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }
}
