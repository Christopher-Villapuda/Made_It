﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Timer : MonoBehaviour
{
    public float startTime =10.0f;
    private float timerEnd = 0.00f;
    public Text textBox;
    public GameObject LM;
    private LoseMenu lm;
    public bool timerActive = true;
    // Start is called before the first frame update
    public void Start()
    {
        textBox.text = startTime.ToString("F2");
        timerActive = true;
        lm = LM.GetComponent<LoseMenu>();
    }
    // Update is called once per frame
    public void Update()
    {
        if (timerActive == true)
        {
            startTime -= Time.deltaTime;
            textBox.text = startTime.ToString("F2");
    
        }
        if (startTime <= 0.00)
        {
            timerActive = false;
            textBox.text = timerEnd.ToString("F2");
            lm.Lose = true;
        }
        else if (timerActive == false)
        {
            //Debug.Log("You win.");
        }
       
    }
    //public void End()
    //{
        
    //}

}
